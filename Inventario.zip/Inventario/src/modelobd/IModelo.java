package modelobd;

/**
 *
 * @author El APRENDIZ www.elaprendiz.net63.net
 */
public interface IModelo {
    
    public static int primero=1;
    public static int ultimo=10;
}
